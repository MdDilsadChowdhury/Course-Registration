package com.example.demo.repository;

import com.example.demo.model.CourseRegistration;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CourseRegistrationRepository extends MongoRepository<CourseRegistration, String> {
    // Additional methods if needed
}
