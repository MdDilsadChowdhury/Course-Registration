package com.example.demo.controller;

import com.example.demo.model.CourseRegistration;
import com.example.demo.service.CourseRegistrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/course-registration")
public class CourseRegistrationController {

    @Autowired
    private CourseRegistrationService courseRegistrationService;

    // Implement API endpoints for course registration
}
