package com.example.demo.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "app")
public class ApplicationProperties {
    private int maxCreditsPerStudent;
    private int maxCoursesPerStudent;

    // getters and setters
}
