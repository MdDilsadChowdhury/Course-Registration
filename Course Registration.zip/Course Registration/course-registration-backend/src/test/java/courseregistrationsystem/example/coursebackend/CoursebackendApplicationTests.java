package courseregistrationsystem.example.coursebackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoursebackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
