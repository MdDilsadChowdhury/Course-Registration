package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document(collection = "courseRegistrations")
public class CourseRegistration {
    @Id
    private String id;
    private String studentId;
    private List<String> courseIds;

    // constructors, getters, setters
}
