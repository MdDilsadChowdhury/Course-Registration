package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document(collection = "students")
public class Student {
    @Id
    private String id;
    private String studentId;
    private String name;
    private String gender;
    private List<String> phoneNumbers;
    private String email;
    private String degree;
    private String instituteName;
    private double gpa;
    private int passingYear;
    private String addressLine1;
    private String addressLine2;
    private String subdistrict;
    private String district;

    // constructors, getters, setters
}
