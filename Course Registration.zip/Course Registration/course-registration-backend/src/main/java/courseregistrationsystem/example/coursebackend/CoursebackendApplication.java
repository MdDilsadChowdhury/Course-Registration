package courseregistrationsystem.example.coursebackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoursebackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoursebackendApplication.class, args);
	}

}
