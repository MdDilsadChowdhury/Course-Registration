package com.example.demo.service;

import com.example.demo.model.CourseRegistration;

public interface CourseRegistrationService {
    CourseRegistration assignCoursesToStudent(String studentId, List<String> courseIds);
    // Additional methods if needed
}
