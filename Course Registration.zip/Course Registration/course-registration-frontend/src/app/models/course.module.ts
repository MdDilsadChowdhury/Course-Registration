import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CourseListComponent } from './course-list.component';
import { CourseRegistrationComponent } from './course-registration.component';

@NgModule({
  declarations: [
    CourseListComponent,
    CourseRegistrationComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    CourseListComponent,
    CourseRegistrationComponent
  ]
})
export class CourseModule { }
